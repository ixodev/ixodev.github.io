<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="terrain" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="terrain_atlas.png" trans="000000" width="1024" height="1024"/>
</tileset>
