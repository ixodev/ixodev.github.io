import os
import pygame as pg

from utils import locate_directory, read_frames_from_file, get_image


LIVES = 25


# Base class for all entities in the whole game
class Entity(pg.sprite.Sprite):
    def __init__(self, spritesheet: str, x: int, y: int):
        super().__init__()

        self.current_spritesheet = spritesheet
        self.spritesheets_directory = locate_directory(spritesheet)
        self.spritesheets = [file for file in os.listdir(self.spritesheets_directory) if file != "frames"]

        self.frame = 0

        self.left = False

        self.velocity = 7.5

        self.frames = read_frames_from_file(f"{self.spritesheets_directory}/frames")

        self.width = pg.image.load(self.current_spritesheet).get_width() / int(self.frames.get(self.current_spritesheet.split("/")[-1]))
        self.height = pg.image.load(self.current_spritesheet).get_height()

        self.image = get_image(self.current_spritesheet, [0, 0, self.width, self.height])
        self.rect = self.image.get_rect().move(x, y)

        self.is_moving = False
        self.is_attacking = False

        self.lives = LIVES

        self.font = pg.font.Font(None, 20)

        self.lost_lives_surface = pg.Surface([0, 0])
        self.has_lost_lives = False
        self.lost_lives_counter = 255
        self.lost_lives_color = "red"

        self.is_dead = False
        self.is_dying = False

    def configure_lost_lives(self, lost_lives: int):
        self.has_lost_lives = True
        self.lost_lives_surface = self.font.render(f"-{str(lost_lives)}", 0, pg.Color(self.lost_lives_color))

    def update_lost_lives(self):
        if self.has_lost_lives:
            if self.lost_lives_counter <= 0:
                self.has_lost_lives = False
                self.lost_lives_counter = 255
                self.lost_lives_surface = pg.Surface([0, 0])

            self.lost_lives_surface.set_alpha(self.lost_lives_counter)
            self.lost_lives_counter -= 10

    def set_animation(self, name: str, reset: bool = True):
        if not name in self.spritesheets:
            raise SystemError("animation not in spritesheets directory!")

        self.current_spritesheet = f"{self.spritesheets_directory}/{name}"

        if reset:
            self.frame = 0

    def update(self, moves: bool = True):

        self.handle_animations(moves)

        if self.lives <= 0:
            self.set_animation("Death.png", reset=False)

        try:
            self.image = get_image(self.current_spritesheet, [self.frame * self.width, 0, self.width, self.height])
            self.image = pg.transform.scale2x(self.image)

            if self.left:
                self.image = pg.transform.flip(self.image, True, False)

            self.image.blit(self.lost_lives_surface, (self.image.get_width() / 2 - self.lost_lives_surface.get_width() / 2, self.image.get_height() / 5))

        except ValueError:
            if self.current_spritesheet.split("/")[-1] == "Death.png":
                self.is_dead = True
                self.is_dying = False

            self.frame = -1

        self.frame += 1

        self.update_lost_lives()


    def moveRight(self):
        self.left = False
        self.rect.x += self.velocity

    def moveLeft(self):
        self.left = True
        self.rect.x += self.velocity * -1

    def handle_animations(self, moves: bool = True):
        pass

    def update_attack(self):
        pass

    def update_jump(self):
        pass

    def die(self):
        self.set_animation("Death.png", reset=True)