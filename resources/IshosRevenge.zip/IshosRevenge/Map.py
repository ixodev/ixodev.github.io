# Written by IxoDev

import pygame as pg

class Map:
    def __init__(self):
        ...