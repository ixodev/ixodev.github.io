# Written by IxoDev

import pygame as pg
import sys


class GameForm:
    def __init__(self, screen: pg.Surface):
        self.screen = screen
        self.second_font = pg.font.Font(None, 30)
        self.second_font.set_italic(True)
        self.instr = self.second_font.render("Press space to continue", 0, pg.Color("white"))

    # To be overwritten
    def render(self):
        pass

    def run(self):
        running = True
        clock = pg.time.Clock()

        while running:
            self.screen.fill(pg.Color("black"))

            self.render()
            self.screen.blit(self.instr, (self.screen.get_width() / 2 - self.instr.get_width() / 2, self.screen.get_height() / 4 * 3.75))

            pg.display.flip()

            for evt in pg.event.get():
                if evt.type == pg.QUIT or evt.type == pg.KEYDOWN and evt.key == pg.K_ESCAPE:
                    pg.quit()
                    sys.exit(0)

                elif evt.type == pg.KEYDOWN and evt.key == pg.K_SPACE:
                    running = False

            clock.tick(25)