# Written by IxoDev

import sys
import pygame as pg
from GameForm import GameForm



class Introduction(GameForm):
    def __init__(self, screen: pg.Surface):
        super().__init__(screen)
        self.title_font = pg.font.Font("assets/fonts/title_font.ttf", 100)
        self.normal_font = pg.font.Font(None, 40)
        self.banner = pg.image.load("assets/images/openzerox-icon-311x228.png")
        self.text = self.normal_font.render("Presents (written by IxoDev)", 0, pg.Color("white"))
        self.big_title = self.title_font.render("Ishos> Revenge>", 0, pg.Color("green"))

    def render(self):
            self.screen.blit(self.banner, (self.screen.get_width() / 2 - self.banner.get_width() / 2, 0))
            self.screen.blit(self.text, (
            self.screen.get_width() / 2 - self.text.get_width() / 2, self.screen.get_height() / 2 - self.text.get_height() / 2))
            self.screen.blit(self.big_title, (self.screen.get_width() / 2 - self.big_title.get_width() / 2,
                                              self.screen.get_height() / 4 * 3.5 - self.big_title.get_height()))