# Isho's Revenge v0.1.0
# Written by IxoDev

try:
    import sys
    import os
    import random
    import pygame as pg
    import pytmx
    import pyscroll
    import math

    from Player import Player
    from Monster import Monster
    from Projectile import Projectile
    from Introduction import Introduction
    from GameOver import GameOver

except ImportError as err:
    raise SystemError(f"An ImportError exception occured. Reason: {err}.")


pg.init()
pg.display.init()
pg.font.init()
pg.mixer.init()


class Game:
    def __init__(self):

        self.screenrect = pg.Rect(0, 0, 1290, 700)
        self.screen = pg.display.set_mode(self.screenrect.size)
        pg.display.set_caption("Isho's Revenge v0.1.0")

        self.collisions = []

        self.screen_ratio_to_ground = 1 / 4
        self.rects = []

        self.sun_radius = 350
        self.sun_speed = 1
        self.sun_cnt = 0
        self.sun_center_x = self.screen.get_width() / 2
        self.sun_center_y = self.screen.get_height() / 2

        self.global_sprite_group = pg.sprite.Group()
        self.player = Player(f"assets/images/Heroes/Players/MartialHero3/Run.png", 0, 0)
        self.player.rect = self.player.rect.move(0, self.screen.get_height() - self.screen.get_height() * self.screen_ratio_to_ground - self.player.rect.h - 20)
        # self.player.image.get_width() / 2 * -1
        # y = self.screen.get_height() - self.player.image.get_height() * 1.5

        self.enemies = pg.sprite.Group()
        self.projectiles = pg.sprite.Group()
        self.create_enemies()

    def add_new_monster(self):
        monster = Monster(f"assets/images/Monsters/{random.choice(os.listdir('assets/images/Monsters'))}/Move.png",
                    random.randint(self.screen.get_width(), self.screen.get_width() * 2),
                          self.screen.get_height() - self.screen.get_height() * self.screen_ratio_to_ground - 150 - 20, self.player,
                          self.screen.get_width())
        self.enemies.add(monster)
        self.projectiles.add(monster.projectile)

    def create_enemies(self):
        for i in range(4):
            self.add_new_monster()

    def check_deaths(self):
        for enemy in self.enemies:
            if enemy.is_dead:
                enemy.respawn(self.screen.get_width())
            elif enemy.is_launching_projectile:
                enemy.projectile.update()
                self.screen.blit(enemy.projectile.image, enemy.projectile.rect)

        if self.player.is_dead:
            game_over = GameOver(self.screen)
            game_over.run()

    def draw_sun(self):
        colors = [pg.Color([255, 255, 0]), pg.Color([255, 255, 26]), pg.Color([255, 255, 51]), pg.Color([255, 255, 77]),
                  pg.Color([255, 255, 102]), pg.Color([255, 255, 128]), pg.Color([255, 255, 153]), pg.Color([255, 255, 179]),
                  pg.Color([255, 255, 204]), pg.Color([255, 255, 230]), pg.Color([255, 255, 255])]

        delta = self.sun_radius / len(colors)

        for color in colors:
            if colors.index(color) == len(colors) - 1:
                pg.draw.circle(self.screen, color, (self.sun_center_x, self.sun_center_y), self.sun_radius * 1.2)
            else:
                pg.draw.circle(self.screen, color, (self.sun_center_x, self.sun_center_y), self.sun_radius)
            self.sun_radius -= delta * 1.01

        self.sun_radius = 350

    def update(self):

        if self.sun_cnt == 20:
            self.sun_center_y += random.randint(self.sun_speed, self.sun_speed + 2)
            self.sun_cnt = -1

        self.sun_cnt += 1

        if self.sun_center_y >= self.screen.get_height() - self.screen.get_height() * self.screen_ratio_to_ground + self.sun_radius:
            game_over = GameOver(self.screen)
            game_over.run()

        self.check_deaths()

        if not self.player.rect.collidelist(self.collisions):
            self.player.is_moving = False
            self.player.update(False)
        else:
            self.player.update(True)

        self.enemies.update()

        if random.randint(0, 100) == 100:
            self.add_new_monster()

    def render(self):
        self.screen.fill(pg.Color("black"))

        self.draw_sun()
        pg.draw.line(self.screen, pg.Color("black"),
                     (0, self.screen.get_height() - self.screen.get_height() * self.screen_ratio_to_ground), (
                     self.screen.get_width(),
                     self.screen.get_height() - self.screen.get_height() * self.screen_ratio_to_ground))
        self.draw_ground()

        self.enemies.draw(self.screen)
        self.screen.blit(self.player.image, self.player.rect)

    def draw_ground(self):

        pg.draw.rect(self.screen, pg.Color("green"), pg.Rect(0, self.screen.get_height() - self.screen.get_height() * self.screen_ratio_to_ground, self.screen.get_width(), self.screen.get_height() * self.screen_ratio_to_ground))

        for rect in self.rects:
            pg.draw.rect(self.screen, pg.Color("black"), rect)

    def generate_random_background(self):
        self.rects = []
        rect_size = 5

        for x in range(int(self.screen.get_width() / rect_size)):
            for y in range(int((self.screen.get_height() - self.screen.get_height() * self.screen_ratio_to_ground) / rect_size), self.screen.get_height()):
                if random.randint(0, 2) == 2:
                    self.rects.append(pg.Rect(x * rect_size, y * rect_size, rect_size, rect_size))

    def run(self):

        running = True
        clock = pg.time.Clock()

        introduction = Introduction(self.screen)
        introduction.run()

        self.generate_random_background()

        while running:

            self.render()

            self.update()

            pg.display.flip()

            clock.tick(15)

            for evt in pg.event.get():
                if evt.type == pg.QUIT or evt.type == pg.KEYDOWN and evt.key == pg.K_ESCAPE:
                    running = False


        pg.quit()
        sys.exit(0)