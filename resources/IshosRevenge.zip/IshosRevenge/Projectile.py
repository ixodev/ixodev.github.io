# Written by IxoDev

import pygame as pg
import math
import random

from utils import locate_directory, read_frames_from_file, get_image


class Projectile(pg.sprite.Sprite):
    def __init__(self, spritesheet: str, x: int, y: int, direction: int, delta_time_counter: float):
        super().__init__()

        self.spritesheet = spritesheet
        self.direction = direction # Should only be 1 or -1
        self.frames = read_frames_from_file(f"{locate_directory(self.spritesheet)}/frames")

        self.width = pg.image.load(self.spritesheet).get_width() / int(self.frames.get(self.spritesheet.split("/")[-1]))
        self.height = pg.image.load(self.spritesheet).get_height()
        self.frame = 0

        self.image = get_image(self.spritesheet, [self.frame, 0, self.width, self.height])
        self.rect = self.image.get_rect().move(x, y)

        self.delta_time_counter = delta_time_counter
        self.delta_time_counter_limit = 5.0

        self.velocity = 50.0
        self.gravity = 20.0

        self.is_animation_finished = False

    def update(self):
        try:
            if not self.is_animation_finished:
                self.image = get_image(self.spritesheet, [self.frame * self.width, 0, self.width, self.height])
                self.image = pg.transform.scale2x(self.image)

                if self.direction == -1:
                    self.image = pg.transform.flip(self.image, True, False)

                if not locate_directory(self.spritesheet).endswith("Goblin"):
                    self.rect.x += self.velocity * self.direction

                else:
                    if self.frame < int(self.frames.get(self.spritesheet.split("/")[-1])) // 4:
                        self.rect.y += self.gravity / 1.2 * -1
                    elif self.frame > int(self.frames.get(self.spritesheet.split("/")[-1])) // 4 and self.frame <= int(self.frames.get(self.spritesheet.split("/")[-1])) // 2:
                        self.rect.y += self.gravity / 1.2
                        self.rect.x += self.velocity * self.direction

        except ValueError:
            self.frame = -1
            self.is_animation_finished = True

        self.frame += 1
