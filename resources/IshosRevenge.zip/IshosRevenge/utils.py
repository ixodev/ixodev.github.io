# Written by IxoDev

import pygame as pg


def locate_directory(spritesheet: str):
    path = spritesheet.split("/")
    directories = [directory for directory in path if directory != path[-1]]

    path = ""
    for directory in directories:
        if directory != directories[0]:
            path += f"/{directory}"
        else:
            path += directory

    return path

def read_frames_from_file(path: str):
    file = open(path)
    frames = dict()

    for line in file.readlines():
        frames.update({line.split(" ")[0]: line.split(" ")[1].split("\n")[0]})

    file.close()
    return frames

def get_image(path: str, rect: list):
    return pg.image.load(path).subsurface(rect)
