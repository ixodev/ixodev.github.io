import pygame as pg

TILE_SIZE = 80

class Tile(pg.sprite.Sprite):
    def __init__(self, image: pg.Surface):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()