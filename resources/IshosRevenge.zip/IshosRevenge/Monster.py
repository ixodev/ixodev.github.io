# Written by IxoDev

import math
import os
import random

from Entity import *
from Player import Player
from Projectile import Projectile


DISTANCE_NEAR_FACTOR = 50
DISTANCE_FAR_FACTOR = 1000


class Monster(Entity):
    def __init__(self, spritesheet: str, x: int, y: int, player: Player, screen_width: int):
        super().__init__(spritesheet, x, y)
        self.player = player
        self.current_distance = 0.0

        self.prev_animation = self.current_spritesheet
        self.deads = 0.0

        self.projectile = Projectile(f"{locate_directory(self.current_spritesheet)}/Projectile.png", self.rect.x, self.rect.y, -1, 0.0)
        self.is_launching_projectile = False
        self.projectile_counter = 0

        self.screen_width = screen_width

    def update_attack(self):
        if self.is_attacking:
            if self.frame >= int(self.frames.get("Attack1.png")):
                self.frame = 0
                self.set_animation(self.prev_animation)
                self.is_attacking = False
                self.left = not self.player.left

    def handle_animations(self, moves: bool = True):
        if not self.is_dead:
            if self.rect.x > self.screen_width - 400:
                self.set_animation("Move.png", reset=False)
                self.rect.x += self.velocity * 1.01 * -1

            self.prev_animation = self.current_spritesheet

            player_center = (self.player.rect.x + self.player.rect.w / 2, self.player.rect.y + self.player.rect.h / 2)
            self_center = (self.rect.x + self.rect.w / 2, self.rect.y + self.rect.h / 2)

            self.current_distance = math.sqrt((self_center[0] - player_center[0]) ** 2 + (self_center[1] - player_center[1]) ** 2)

            if player_center[0] < self_center[0]:
                self.left = True
            else:
                self.left = False

            if self.current_distance >= DISTANCE_NEAR_FACTOR and self.current_distance <= DISTANCE_FAR_FACTOR:

                self.is_moving = True
                self.set_animation("Move.png", reset=False)

                if self.rect.x < self.player.rect.x:
                    self.set_animation("Move.png", reset=False)
                    self.moveRight()
                elif self.rect.x > self.player.rect.x:
                    self.set_animation("Move.png", reset=False)
                    self.moveLeft()

            elif self.current_distance <= DISTANCE_NEAR_FACTOR:
                self.is_attacking = True
                self.set_animation("Attack.png", reset=False)

                lost_lives = random.randint(5, 10)
                self.player.lives -= lost_lives
                self.player.configure_lost_lives(lost_lives)
                self.player.hurts = True

                if self.player.is_attacking:
                    if "Shield.png" in os.listdir(locate_directory(self.current_spritesheet)) and random.randint(0, 1):

                        self.is_attacking = False
                        self.set_animation("Shield.png", reset=False)

                    else:
                        lost_lives = random.randint(2, 5)

                        self.lives -= lost_lives
                        self.configure_lost_lives(lost_lives)
                        self.set_animation("TakeHit.png", reset=False)

            else:
                self.is_attacking = False
                if random.randint(0, 20) == 20:
                    self.is_moving = True
                    self.set_animation("Move.png", reset=False)
                    self.rect.x += self.velocity * 1.2 * -1
                else:
                    self.is_moving = False
                    if not self.spritesheets_directory.endswith("FlyingEye"):
                        self.set_animation("Idle.png", reset=False)
                    else:
                        self.set_animation("Move.png", reset=False)

        if self.current_distance <= DISTANCE_FAR_FACTOR and self.rect.x < self.screen_width - self.rect.w - 500 and random.randint(0, 3) == 3:
            self.is_launching_projectile = True

        if self.is_launching_projectile and self.projectile.is_animation_finished:
            self.projectile.is_animation_finished = True
            self.projectile.rect.center = self.rect.center
            self.is_launching_projectile = False

    def respawn(self, screen_width: int):
        self.deads += 1
        self.rect.x = screen_width
        self.lives = LIVES * self.deads / 1.25
        self.is_dead = False