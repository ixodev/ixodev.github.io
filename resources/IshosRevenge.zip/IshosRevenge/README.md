# Isho's Revenge v0.1.0
## Written by <a href="https://www.github.com/ixodev" style="text-decoration: none;">IxoDev</a>. Spritesheets created by <a href="https://luizmelo.itch.io" style="text-decoration: none;">LuizMelo</a>.

### This is the first version of Isho's Revenge, a 2D platformer game. It is the story of a japanese Samurai who wants to experiment his fighter skills.
### He will survive to many adventures before his fight with the Big Blue Samurai, his worst enemy of all...

### <u>Controls:<u>
### WASD, ZQSD or arrow keys to move
### Space key to fight
### Pick up items by pressing E

### <u>How to run the game:<u>
### If you have Python and Pygame installed, just open a terminal in the project folder, and type the following command:
### python3 main.py OR python main.py
### Or just open the file with a Python interpreter.
### You can also run the executable named ishos_revenge.exe...

## Have fun!