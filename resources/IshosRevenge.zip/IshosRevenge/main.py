# Written by IxoDev

from Game import Game

if __name__ == "__main__":
    app = Game()
    app.run()