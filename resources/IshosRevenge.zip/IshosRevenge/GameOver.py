# Written by IxoDev

import sys
import pygame as pg

from GameForm import GameForm


class GameOver(GameForm):
    def __init__(self, screen: pg.Surface):
        super().__init__(screen)
        self.font = pg.font.Font("assets/fonts/title_font.ttf", 80)

        self.title = self.font.render("Game> Over>", 0, pg.Color("red"))

    def render(self):
        self.screen.blit(self.title, (self.screen.get_width() / 2 - self.title.get_width() / 2,
                                      self.screen.get_height() / 2 - self.title.get_height() / 2))