# Written by IxoDev
import random

from Entity import *


class Player(Entity):
    def __init__(self, spritesheet: str, x: int, y: int):
        super().__init__(spritesheet, x, y)
        self.velocity = 15

        self.jump_border = 10
        self.jump_index = self.jump_border
        self.is_jumping = False
        self.prev_y = self.rect.y
        self.y_before_jump = self.rect.y

        self.preview_animation = ""
        self.set_animation("Idle.png")

        self.attack_counter = 0
        self.attack_counter_updater = False

        self.lives = LIVES * 4 * 100
        self.lost_lives_color = "blue"
        self.hurts = False

    def update_jump(self):
        if self.is_jumping:
            if self.jump_index >= self.jump_border * -1:
                self.rect.y -= (self.jump_index * abs(self.jump_index)) * 0.5
                self.jump_index -= 1
            else:
                self.jump_index = self.jump_border
                self.is_jumping = False
                self.set_animation("Run.png")
                self.rect.y = 700 - 700 * (1 / 4) - self.rect.h - 20
            if self.rect.y > self.prev_y:
                self.set_animation("Fall.png", reset=False)

    def update_attack(self):
        if self.is_attacking:
            if self.frame >= int(self.frames.get("Attack1.png")):
                self.frame = 0
                self.set_animation("Idle.png")

        if self.attack_counter_updater:
            self.attack_counter += 1

            if self.attack_counter >= 5:
                self.attack_counter = 0
                self.attack_counter_updater = False

    def handle_moves(self):
        key = pg.key.get_pressed()

        if key[pg.K_LEFT] or key[pg.K_a] or key[pg.K_q]:
            self.is_attacking = False
            self.is_moving = True
            self.left = True

            if not self.is_jumping:
                self.rect.x += self.velocity * -1
                self.set_animation("Run.png", reset=False)
            else:
                self.rect.x += (self.velocity - 3) * -1
                self.set_animation("Jump.png", reset=False)

        elif key[pg.K_RIGHT] or key[pg.K_d]:
            self.is_attacking = False
            self.is_moving = True
            self.left = False

            if not self.is_jumping:
                self.rect.x += self.velocity
                self.set_animation("Run.png", reset=False)
            else:
                self.rect.x += (self.velocity - 3)
                self.set_animation("Jump.png", reset=False)

        else:
            self.is_moving = False

        if key[pg.K_UP] or key[pg.K_w] or key[pg.K_z] and not self.is_jumping:
            self.is_jumping = True
            self.set_animation("Jump.png", reset=False)

    def handle_animations(self, moves: bool = True):
        if self.lives > 0:
            if moves:
                self.handle_moves()

            key = pg.key.get_pressed()
            if not self.is_moving and not self.is_attacking and not self.is_jumping:
                self.set_animation("Idle.png", reset=False)

            self.prev_y = self.rect.y
            self.update_jump()

            if key[pg.K_SPACE] and not self.attack_counter_updater and not self.is_moving and not self.is_dead and not self.is_jumping:
                if str(3) in self.spritesheets_directory:
                    self.set_animation(f"Attack{random.randint(1, 3)}.png")
                else:
                    self.set_animation(f"Attack{random.randint(1, 2)}.png")
                self.is_attacking = True
                self.attack_counter_updater = True

            self.update_attack()

        else:
            if not self.is_dying:
                self.die()
                self.is_dying = True