<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="water" tilewidth="16" tileheight="16" tilecount="476" columns="28">
 <image source="TilesetWater.png" width="448" height="272"/>
</tileset>
