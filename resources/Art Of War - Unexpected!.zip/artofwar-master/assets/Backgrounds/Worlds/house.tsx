<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="house" tilewidth="16" tileheight="16" tilecount="759" columns="33">
 <image source="TilesetHouse.png" width="528" height="368"/>
</tileset>
