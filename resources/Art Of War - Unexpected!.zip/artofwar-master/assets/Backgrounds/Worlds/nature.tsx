<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="nature" tilewidth="16" tileheight="16" tilecount="504" columns="24">
 <image source="TilesetNature.png" width="384" height="336"/>
</tileset>
