<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="dungeon" tilewidth="16" tileheight="16" tilecount="48" columns="12">
 <image source="TilesetDungeon.png" width="192" height="64"/>
</tileset>
