<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="village_abandoned" tilewidth="16" tileheight="16" tilecount="240" columns="20">
 <image source="TilesetVillageAbandoned.png" width="320" height="192"/>
</tileset>
