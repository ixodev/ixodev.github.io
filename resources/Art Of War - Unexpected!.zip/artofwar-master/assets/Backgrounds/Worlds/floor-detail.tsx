<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="floor_detail" tilewidth="16" tileheight="16" tilecount="80" columns="16">
 <image source="TilesetFloorDetail.png" width="256" height="80"/>
</tileset>
