<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="wall-simple" tilewidth="16" tileheight="16" tilecount="110" columns="10">
 <image source="TilesetWallSimple.png" width="160" height="176"/>
</tileset>
