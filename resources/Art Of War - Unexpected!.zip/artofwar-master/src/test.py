import os
"""
dirs = os.listdir("assets/Actor/Monster")
for d in dirs:
    for f in os.listdir(f"assets/Actor/Monster/{d}"):
        if f.endswith(".png") and f != "Faceset.png" and f != "faceset.png":
            file = open(f"assets/Actor/Monster/{d}/{f}", "rb")
            s = file.read()
            file.close()

            os.remove(f"assets/Actor/Monster/{d}/{f}")

            file = open(f"assets/Actor/Monster/{d}/SpriteSheet.png", "ab")
            file.write(s)
            file.close()

"""
