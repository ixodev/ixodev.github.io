import pygame as pg

from utils import get_surface
from entity import Entity



DOWN = 0
UP = 1
LEFT = 2
RIGHT = 3

class Character(Entity):
    def __init__(self, name: str, pos: pg.math.Vector2):
        super().__init__(name, pos)
        self.entity_type = "character"
        self.wait_moving = False

    def handle_inputs(self):
        ...

    def update_entity(self):


        self.save_location()

        self.handle_inputs()

        self.rect.topleft = self.position
        self.feet.midbottom = self.rect.midbottom

        if not self.wait_moving:
            self.inc_texcoords('y')
            self.set_current_image()


        #if self.entity_type != "player":
         #   self.scale_image()