import pygame as pg


SIZE = 3
FONT_PATH = "assets/HUD/Font/Font.ttf"
global_font = pg.font.Font(FONT_PATH, 15)

dialogbox_bounds = {
    "DialogBoxSimple": ((11 * SIZE, 11 * SIZE), (304 * SIZE, 48 * SIZE)),
    "DialogBox": ((10 * SIZE, 18 * SIZE), (288 * SIZE, 48 * SIZE)),
    "DialogBoxFaceset": ((54 * SIZE, 18 * SIZE), (288 * SIZE, 46 * SIZE))
}

dialogbox_surfaces = {
    "DialogBoxSimple": pg.image.load("assets/HUD/Dialog/DialogBoxSimple.png"),
    "DialogBox": pg.image.load("assets/HUD/Dialog/DialogBox.png"),
    "DialogBoxFaceset": pg.image.load("assets/HUD/Dialog/DialogBoxFaceset.png")
}

dialogbox_facesets = {
    "DialogBoxSimple": False,
    "DialogBox": False,
    "DialogBoxFaceset": True
}

tooltip_bounds = {
    "DialogBox": ((5 * SIZE, 2 * SIZE), (68 * SIZE, 9 * SIZE)),
    "DialogBoxFaceset": ((5 * SIZE, 2 * SIZE), (68 * SIZE, 9 * SIZE))
}


class DialogBox:
    def __init__(self, messages: list, screen: pg.Surface):
        self.dialog_type = "DialogBoxSimple"

        self.messages = messages
        self.screen = screen
        self.index = 0
        self.character = 0

        self.current_dialogbox = None
        self.old_surface = None

        self.char_width = global_font.render("a", False, [0, 0, 0]).get_width()
        self.char_height = global_font.render("a", False, [0, 0, 0]).get_height()
        self.set_char_pos_start()

        self.set_should_draw(True)
        self.end = False
        self.is_drawing_tooltip = False

    def open_new_dialogbox(self):
        self.current_dialogbox = dialogbox_surfaces.get(self.dialog_type)
        self.current_dialogbox = pg.transform.scale(self.current_dialogbox,
                                                    (self.current_dialogbox.get_width() * 3, self.current_dialogbox.get_height() * 3))

    def set_char_pos_start(self):
        self.char_x = dialogbox_bounds.get(self.dialog_type)[0][0]
        self.char_y = dialogbox_bounds.get(self.dialog_type)[0][1]

    def new_message(self):
        if self.index == len(self.messages) - 1:
            self.set_end_messages()
            return

        self.character = 0
        self.index += 1
        self.open_new_dialogbox()

    def set_end_messages(self):
        self.set_should_draw(False)
        self.end = True

    def check_eol(self):
        if self.char_x >= dialogbox_bounds.get(self.dialog_type)[1][0] - self.char_width:

            self.char_y += self.char_height

            self.char_x = dialogbox_bounds.get(self.dialog_type)[0][0] - self.char_width * 2 if self.messages[self.index][self.character + 1] == " " \
                else dialogbox_bounds.get(self.dialog_type)[0][0] - self.char_width

            if self.char_y >= dialogbox_bounds.get(self.dialog_type)[1][1] - self.char_height:
                self.set_should_draw(False)
                self.set_char_pos_start()
                self.open_new_dialogbox()

    def set_should_draw(self, val: bool):
        self.should_draw = val

    def copy_old_surface(self):
        self.old_surface = self.current_dialogbox

    # For dialog boxes with tooltip activated
    def update_tooltip(self):
        ...

    def update(self, keys: list):
        #if self.is_drawing_tooltip:
         #   self.update_tooltip()
          #  return

        if self.character > len(self.messages[self.index]) - 1:
            self.new_message()

        if self.should_draw:
            surface = global_font.render(self.messages[self.index][self.character], False, [0, 0, 0])
            surface = pg.transform.scale(surface, (surface.get_width(), surface.get_height()))
            self.current_dialogbox.blit(surface, (self.char_x, self.char_y))
            self.copy_old_surface()

            self.check_eol()

            self.char_x += self.char_width
            self.character += 1

        else:
            if True in keys:
                self.set_should_draw(True)

    def draw(self):
        if self.should_draw:
            self.screen.blit(self.current_dialogbox, (0, 0))
        else:
            self.screen.blit(self.old_surface, (0, 0))

    def show(self):
        self.open_new_dialogbox()




class DialogBoxTooltip(DialogBox):
    def __init__(self, messages: list, screen: pg.Surface, tooltips: list):
        self.dialog_type = "DialogBox"
        super().__init__(messages, screen)
        self.is_drawing_tooltip = True

    def set_tooltip_start(self):
        ...

    def update_tooltip(self):
        ...