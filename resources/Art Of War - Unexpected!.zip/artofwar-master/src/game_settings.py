# Game settings

import os

WINDOW_WIDTH =  1224 #768
WINDOW_HEIGHT = 768
WINDOW_TITLE = "Art Of War"

FPS = 60

PARENT_PATH = os.path.dirname(os.getcwd()) + f"{os.sep}assets{os.sep}"

TEXTURE_SCALING = 3