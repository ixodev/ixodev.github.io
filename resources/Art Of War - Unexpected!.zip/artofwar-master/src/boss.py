import pygame as pg
from entity import Entity



class Boss(Entity):
    def __init__(self, name: str, pos: pg.math.Vector2):
        super().__init__(name, pos)

        self.states = {
            "move": False,
            "attack": False,
            "hit": False,
            "jump": False,
            "dead": False,
            "idle": True
        }

        self.set_animation("default_animation")

    def set_states_except(self, s: str, val: bool):
        for key in self.states.keys():
            if key != s:
                self.states[key] = val
            else:
                self.states[key] = not val

    def get_current_state(self):
        for key in self.states.keys():
            if self.states.get(key):
                return key

        raise ValueError("Boss must have at least 1 state activated")

    def update_entity(self):
        self.save_location()

        keys = pg.key.get_pressed()

        self.set_animation(self.get_current_state())
        self.inc_texcoords('x')

        if self.animation_ended:
            self.set_animation("default_animation")
            self.set_states_except("idle", False)

        self.set_current_image()



    def action(self, val: str):
        self.tx = 0
        self.set_states_except(val, False)
