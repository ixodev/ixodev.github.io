import pygame as pg


def get_surface(surface: pg.Surface, rect: list):
    image = pg.Surface([rect[2], rect[3]])
    image.blit(surface, (0, 0), (rect[0], rect[1], rect[2], rect[3]))
    image.set_colorkey([0, 0, 0])
    return image