import pygame as pg
import pytmx
import pyscroll

from game_settings import *
from asset_manager import AssetManager
from entity import *
from player import Player
from character import Character
from monster import Monster
from boss import Boss


ZOOM = 3

COLLISION_ID = "c"
SWITCH_MAP_AREA_ID = "m_"
SPAWN_POINT_ID = "s_"
MAIN_SPAWN_POINT_FULL = "s_main"
SPAWN_CHARACTER_ID = "ec_"
SPAWN_MONSTER_ID = "em_"
SPAWN_BOSS_ID = "eb_"


class GameMap:
    def __init__(self, map_path: str, screen: pg.Surface, player: Player):
        self.screen = screen
        self.asset_manager = AssetManager()
        self.player = player
        self.player_last_actual_position = self.player.position.copy()
        self.map_path = map_path
        self.filename = self.map_path.split('/')[-1]
        self.tmx_data = pytmx.util_pygame.load_pygame(map_path)
        self.map_data = pyscroll.data.TiledMapData(self.tmx_data)
        self.map_layer = pyscroll.orthographic.BufferedRenderer(self.map_data, self.screen.get_size())
        self.map_layer.zoom = TEXTURE_SCALING

        self.group = pyscroll.PyscrollGroup(map_layer=self.map_layer, default_layer=1)
        self.entities = []
        self.add_entity(self.player)
        self.walls = []
        self.switch_map_areas = {}
        self.spawn_points = {}
        self.main_spawn_point = ()

        self.map_to_switch_to = None
        self.create_objects()

    def add_entity(self, entity: Entity):
        self.group.add_internal(entity, 1)
        #self.group.add_internal(entity.weapon, 1)
        self.entities.append(entity)

    def create_objects(self):
        self.walls.clear()

        for obj in self.tmx_data.objects:
            if obj.name.startswith(COLLISION_ID):
                self.walls.append(pg.Rect(obj.x, obj.y, obj.width, obj.height))
            elif obj.name == MAIN_SPAWN_POINT_FULL:
                self.main_spawn_point = (obj.x, obj.y)
            elif obj.name.startswith(SWITCH_MAP_AREA_ID):
                self.switch_map_areas.update({(obj.x, obj.y, obj.width, obj.height): obj.name.split('_')[1]})
            elif obj.name.startswith(SPAWN_POINT_ID):
                self.spawn_points.update({obj.name.split('_')[1]: (obj.x, obj.y, 0, 0)})

            else:
                entity_name = obj.name.split('_')[-1][0].upper() + obj.name.split('_')[-1][1:]

                if obj.name.startswith(SPAWN_CHARACTER_ID):
                    entity = Character(entity_name, pg.math.Vector2(obj.x, obj.y))
                elif obj.name.startswith(SPAWN_MONSTER_ID):
                    entity = Monster(entity_name, pg.math.Vector2(obj.x, obj.y))
                elif obj.name.startswith(SPAWN_BOSS_ID):
                    entity = Boss(entity_name, pg.math.Vector2(obj.x, obj.y))

                self.add_entity(entity)

    def update(self):
        self.check_collisions()
        map_switch_string = self.check_map_switches()
        self.group.update()

        if not self.player.wait_moving:
            self.group.center(self.player.rect.center)


        if map_switch_string is not None:
            self.map_to_switch_to = map_switch_string
        else:
            self.map_to_switch_to = None


    def draw(self):
        self.group.draw(self.screen)

    def check_collisions(self):
        if self.player.feet.collidelist(self.walls) > -1:
            self.player.move_back()
            self.player.wait_moving = True

        for sprite in self.entities:
            if sprite.feet.collidelist(self.walls) > -1:
                sprite.move_back()


    def check_map_switches(self):
        for switch_area in self.switch_map_areas.keys():
            pg.draw.rect(self.screen, pg.Color("white"), switch_area)
            if self.player.feet.colliderect(pg.Rect(switch_area[0], switch_area[1], switch_area[2], switch_area[3])):
                return self.switch_map_areas.get(switch_area)

        return None

    def __repr__(self):
        return f"GameMap (game_map.py), filename: {self.filename}"