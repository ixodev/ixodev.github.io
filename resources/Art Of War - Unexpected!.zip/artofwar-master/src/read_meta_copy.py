""" Module used for reading meta files, provides functions for string manipulation, etc. """

import pygame as pg
from utils import get_surface

# Builtin variables

SIZE = "size"
DEFAULT_ANIMATION = "default_animation"

FACESET = "faceset"
IDLE = "idle"
WALK = "walk"
JUMP = "jump"
CHARGE = "charge"
ATTACK = "attack"
DEAD = "dead"
ITEM = "item"
SPECIAL1 = "special1"
SPECIAL2 = "special2"

# lists to store numbers
VAR_ARRAY = [FACESET, IDLE, WALK, CHARGE, ATTACK, JUMP, DEAD, ITEM, SPECIAL1, SPECIAL2]
NUMBERS = [str(x) for x in range(10)]


""" Converts a list to a string, with each element of the list separated by delimiter """
def list_to_string(l: list, delimiter: str):
    stringbuilder = ""
    x = 0
    for e in l:
        stringbuilder += e + delimiter if x < len(l) - 1 else e
        x += 1

    return stringbuilder

""" Remove newlines in a string """
def remove_newline(string: str):
    return string.replace('\n', '')

""" Gets the "size" attribute of the meta file """
def compute_size(size: str):
    if not 'x' in size: # like size=16x16 for example
        raise SyntaxError(f"Syntax error: {size}")

    values = size.split('x') # Split string

    if len(values) != 2:
        raise ValueError(f"Value error: {size}. Need 2 values.")

    return (int(remove_newline(values[0])), int(remove_newline(values[1]))) # tuple with size in it


""" Helper function for create_anim_sequence(str) """
def create_anim_sequence_helper(texcoords: list, ):
    int_texcoords = []

    for t in texcoords:
        if not (t[0] == '[' and t[len(t) - 1] == ']'): # Must be in brackets
            raise SyntaxError(f"Unknown expression")

        # Remove the brackets
        # [0, 0, 1, 1]
        # ^          ^
        # |          |

        t = t[1:]
        t = t[:-1]

        digits = t.split(',')
        if len(digits) != 4:
            raise ValueError(f"Error: {string}. 2D texture coordinates must have 4 values")

        tmp_int_texcoords = []
        for digit in digits:
            tmp_int_texcoords.append(int(digit))

        int_texcoords.append(tmp_int_texcoords)

    return int_texcoords

"""
Creates an animation sequence with a given string. Example:
[[0,0,1,1],[0,1,1,1],[0,2,1,1],[0,3,1,1]]
"""
def create_anim_sequence(string: str):
    if not (string[0] == '[' and string[len(string) - 1] == ']'):
        raise SyntaxError(f"Unknown expression: {string}")

    # Remove the "[]" brackets
    # [[0,0,1,1],[0,1,1,1],[0,2,1,1],[0,3,1,1]]
    # ^                                       ^
    # |                                       |
    # This one here                          and this one here

    string = string[1:]
    string = string[:-1]

    if not ',' in string or not '[' in string or not ']' in string:
        raise SyntaxError(f"Unknown expression: {string}")


    # Splits the string by commas
    # [[0,0,1,1],[0,1,1,1],[0,2,1,1],[0,3,1,1]]
    #           ^         ^         ^
    #           |         |         |

    return create_anim_sequence_helper(string.split(','))


""" Creates a spritesheet from an animation sequence """
def create_spritesheet(path, texcoords_sequence: list, sprite_width: int, sprite_height: int):
    spritesheet = pg.Surface([sprite_width, len(texcoords_sequence) * sprite_height])
    surfaces = []

    for texcoords in texcoords_sequence:
        surfaces.append(get_surface(pg.image.load(path), [texcoords[0] * sprite_width, texcoords[1] * sprite_height, sprite_width, sprite_height]))

    for surface in surfaces:
        spritesheet.blit(surface, (0, surfaces.index(surface) * sprite_height))

    return spritesheet


""" Analyzes each line of the file """
def analyze_line(dir_of_current_meta_file: str, line: str, character_dict: dict):
    values = line.split('=') # Separate operands

    if len(values) != 2:
        raise SyntaxError(f"Unknown expression: {line}")

    if values[0] == SIZE: # size is a special value with a special syntax
        character_dict.update({SIZE: compute_size(values[1])}) # Update dict
        return

    # As an example, a thing like this:
    # default_animation=walk,[[0,0,1,1],[0,1,1,1],[0,2,1,1],[0,3,1,1]]
    # OR
    # default_animation=Idle.png,[[0,0,1,1],[0,1,1,1],[0,2,1,1],[0,3,1,1]]
    # Here we define a sequence of texture coordinates to create an animation
    # Let's check if this expression is correct

    elif '[' in values[1] and ']' in values[1]:
        l = values[1].split(',')
        l = l[1:]
        res_name = values[1].split(',')[0]
        res = res_name
        if res_name in character_dict.keys():
            res = character_dict.get(res_name)

        spritesheet = create_spritesheet(dir_of_current_meta_file + '/' + res, create_anim_sequence(list_to_string(l, ',')),
                character_dict.get(SIZE)[0], character_dict.get(SIZE)[1])

        character_dict.update({values[0], spritesheet})
        return


    # Example, it could be:
    # xxx=xxx.png
    # xxx2=xxx
    # Then xxx2 is xxx.png
    string_to_update = character_dict.get(remove_newline(values[1])) if values[1] in character_dict.keys() else remove_newline(values[1])
    character_dict.update({values[0]: string_to_update}) # Update dict

def read_meta_file(filename: str):
    character_dict = {}

    file = open(filename, "r")
    lines = file.readlines()
    file.close()

    dirname = filename.split('/')
    dirname = dirname[:-1]
    dirname = list_to_string(dirname, '/')

    for line in lines:
        if not line.startswith('#') and line != '\n' and line != "\n\n" and line != '': # "#" is a comment
            analyze_line(dirname, line, character_dict) # Each line which is not a comment or \n

    return character_dict # Returns dictionary



# Test case, this can be removed
if __name__ == "__main__":
    print(read_meta_file("assets/Actor/Monsters/Mushroom/animations.meta"))