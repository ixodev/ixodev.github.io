import pygame as pg


class FX(pg.sprite.Sprite):
    ...
