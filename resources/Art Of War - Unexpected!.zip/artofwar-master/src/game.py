import sys

import pygame as pg

from game_settings import *
from asset_manager import AssetManager
from world import World



class Game:
    def __init__(self):
        self.init_variables()
        self.init_window()
        self.init_components()

    def init_variables(self):
        self.is_running = True

    def init_window(self):
        self.asset_manager = AssetManager()
        pg.mixer_music.load(self.asset_manager.get_file_path("Musics/0 - TRON THE SON OF FLYNN.mp3"))
        pg.mixer_music.play(-1, 0.0, 0)

        self.clock = pg.time.Clock()

        self.screen = pg.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pg.display.set_caption(WINDOW_TITLE)
        pg.display.set_icon(self.asset_manager.get_surface("icon.png"))

    def init_components(self):
        self.world = World(1, self.screen)

    def update(self, keys: list):
        self.world.update()

    def render(self):
        self.screen.fill([255, 255, 255])
        self.world.draw()
        pg.display.flip()

    def run(self):
        self.screen.fill(pg.Color("white"))
        pg.display.flip()


        while self.is_running:
            keys = pg.key.get_pressed()

            self.update(keys)
            self.render()

            pg.display.flip()

            for evt in pg.event.get():
                if evt.type == pg.QUIT or evt.type == pg.KEYDOWN and evt.key == pg.K_ESCAPE:
                    self.is_running = False

            self.clock.tick(FPS)


