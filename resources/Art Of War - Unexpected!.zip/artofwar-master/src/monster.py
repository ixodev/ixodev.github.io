import random

import pygame as pg
from entity import *


VEL = 7

class Monster(Entity):
    def __init__(self, name: str, pos: pg.Vector2):
        super().__init__(name, pos)
        self.current_animation_string = "default_animation"
        self.position = [pos.x, pos.y]

    def update_entity(self):

        self.set_current_image()
        self.inc_texcoords('y')
